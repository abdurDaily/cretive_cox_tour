<?php $__env->startSection('frontend_contains'); ?>

    <div class="table-responsive shadow-sm  p-2 mt-3">
        <div class="header">
            <h3 class="text-center mb-3">Register Members</h3>
            <div class="d-flex justify-content-between">
                <p>Total Official Members Going: <b class="btn-dark btn"><?php echo e($totalGoinMembers); ?> / <?php echo e($totalMembers); ?></b>
                </p>
                <p>Total Guest : <b class="btn-dark btn"><?php echo e($totalGuest); ?> </b> </p>
                <p>Total Members : <b class="btn-dark btn"><?php echo e($totalMembersGuest); ?> </b> </p>
            </div>


            <div class="d-flex mb-3">


                <!-- Button trigger modal -->
                <button type="button" style="padding: 10px 15px;" data-bs-toggle="modal" data-bs-target="#goingMembers">
                    Going Members
                </button>

                
                <button type="button" style="padding: 10px 15px; margin:0 10px;" data-bs-toggle="modal"
                    data-bs-target="#notGoingMembers">
                    Not Going Members
                </button>


                
                <button type="button" style="padding: 10px 30px; margin-right:10px;" data-bs-toggle="modal"
                    data-bs-target="#guest">
                    Guest
                </button>
            </div>


            <!-- Modal going -->
            <div class="modal fade" id="goingMembers" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Going Members</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Official Stuffs</p>
                            <table class="table table-hover table-bordered">
                                <tr>
                                    <th>Sn</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                </tr>

                                <?php $__empty_1 = true; $__currentLoopData = $goingMembersDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $goingMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($goingMember->name); ?></td>
                                        <td>
                                            <a style="text-decoration: none; color:#000;"
                                                href="tel:<?php echo e($goingMember->phone); ?>"><?php echo e($goingMember->phone); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3">No data found!</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>





            <!-- Modal not going-->
            <div class="modal fade" id="notGoingMembers" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Not Going Members</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Official Stuffs</p>
                            <table class="table table-hover table-bordered">
                                <tr>
                                    <th>Sn</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                </tr>

                                <?php $__empty_1 = true; $__currentLoopData = $notgoingMembersDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $goingMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($goingMember->name); ?></td>
                                        <td>
                                            <a style="text-decoration: none; color:#000;"
                                                href="tel:<?php echo e($goingMember->phone); ?>"><?php echo e($goingMember->phone); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3">No data found!</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Modal guest-->
            <div class="modal fade" id="guest" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Going Members</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Guest</p>
                            <table class="table table-hover table-bordered">
                                <tr>
                                    <th>Sn</th>
                                    <th>Guest Name</th>
                                    <th>Ref. Name</th>
                                    <th>Phone</th>
                                </tr>

                                <?php $__empty_1 = true; $__currentLoopData = $GuestDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $GuestDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e(Str::limit($GuestDetail->name, 8, '...')); ?></td>
                                        <td><?php echo e(Str::limit($GuestDetail->users->name, 8, '...')); ?></td>
                                        <td>
                                            <a style="text-decoration: none; color:#000;"
                                                href="tel:<?php echo e($GuestDetail->users->phone); ?>"><?php echo e($GuestDetail->users->phone); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3">No data found!</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>




        </div>
        <div class="table-responsive">
            <table class="table-bordered table table-striped table-hover text-center table-v-center">
                <tr>
                    <th>Sn.</th>
                    <th>Name</th>
                    <th>Is Going</th>
                    <th>email</th>
                    <th>Phone</th>
                    <th>T-shirt</th>
                    <th>Opinion</th>
                    <th>Ad Name</th>
                    <th>M</th>
                    <th>L</th>
                    <th>XL</th>
                    <th>XXL</th>
                    <th>Single R</th>
                    <th>Couple R</th>
                </tr>

                <?php $__empty_1 = true; $__currentLoopData = $allRegisters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>


                        <td
                            <?php if($register->additinalMembers != null && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e(++$key); ?></td>
                        <td
                            <?php if($register->additinalMembers && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e($register->name); ?></td>
                        <td
                            <?php if($register->additinalMembers && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e($register->is_going === 1 ? 'Yes' : 'No'); ?></td>
                        <td
                            <?php if($register->additinalMembers && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e($register->email); ?></td>
                        <td
                            <?php if($register->additinalMembers && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e($register->phone); ?></td>
                        <td
                            <?php if($register->additinalMembers && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e($register->tshirt_size); ?></td>
                        <td
                            <?php if($register->additinalMembers && count($register->additinalMembers) > 0): ?> rowspan="<?php echo e(count($register->additinalMembers) + 1); ?>" <?php endif; ?>>
                            <?php echo e($register->opinion); ?></td>

                        <?php if(!$register->additinalMembers || count($register->additinalMembers) == 0): ?>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                        <?php endif; ?>
                    </tr>
                    <?php $__currentLoopData = $register->additinalMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($member->name); ?></td>
                            <td><?php echo e($member->m_size); ?></td>
                            <td><?php echo e($member->l_size); ?></td>
                            <td><?php echo e($member->xl_size); ?></td>
                            <td><?php echo e($member->xxl_size); ?></td>
                            <td><?php echo e($member->single_room); ?></td>
                            <td><?php echo e($member->couple_room); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\cretive_cox_tour\resources\views/frontend/register/allRegister.blade.php ENDPATH**/ ?>