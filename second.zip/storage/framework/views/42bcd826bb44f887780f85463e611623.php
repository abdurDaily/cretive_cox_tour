<?php $__env->startSection('frontend_contains'); ?>

<div class="table-responsive shadow-sm  p-2 mt-3" >
    <div class="header">
        <h3 class="text-center mb-5">All Transactions</h3>
    </div>
    <div class="table-responsive">
        <h5 class="text-end mb-3">Total Transaction: <span style="background: #E42625;color:#fff; padding:10px; display:inline-block;border-radius:10px;"><?php echo e($totalTransaction); ?></span> </h5>
        <table class="table table-striped table-hover text-center">
            <tr>
                <th>Sn.</th>
                <th>Transaction Title</th>
                <th>Amount</th>
            </tr>
    
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($transaction->transaction_name); ?></td>
                    <td><?php echo e($transaction->transaction_amount); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center text-danger py-5">No Data found!</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\cretive_cox_tour\resources\views/frontend/transaction/allTransaction.blade.php ENDPATH**/ ?>