<?php $__env->startSection('frontend_contains'); ?>
    <div class="row mt-2 g-3">

        <div class="header text-center">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session()->get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <span style="color: #E42625;"><iconify-icon icon="carbon:view-filled" width="24"
                    height="24"></iconify-icon></span>
            <h3 class="text-center mb-3">Creative Cox's Tour 2025 </h3>
        </div>

        <div class="col-lg-4 text-center mx-auto">
            <div class="shadow p-5">
                <span
                    style="width:40px;height:40px;display:inline-block;background:#E42625;color:#fff; text-align:center; line-height:50px;border-radius:50%;"><iconify-icon
                        icon="material-symbols:note-alt-rounded" width="24" height="24"></iconify-icon></span>
                <h4 class="mt-3"> <a style="text-decoration: none; color:#000;"
                        href="<?php echo e(route('backend.registrations.view')); ?>">Register Members</a> </h4>
            </div>
        </div>


        <div class="col-lg-4 text-center">
            <div class="shadow p-5">
                <span
                    style="width:40px;height:40px;display:inline-block;background:#E42625;color:#fff; text-align:center; line-height:50px;border-radius:50%;"><iconify-icon
                        icon="mingcute:car-fill" width="24" height="24"></iconify-icon></span>
                <h4 class="mt-3"><a style="text-decoration: none; color:#000;"
                        href="<?php echo e(route('backend.transport.view')); ?>">Transport Schedule</a></h4>
            </div>
        </div>




        <div class="col-lg-4 text-center">
            <div class="shadow p-5">
                
                <span
                    style="width:40px;height:40px;display:inline-block;background:#E42625;color:#fff; text-align:center; line-height:50px;border-radius:50%;"><iconify-icon
                        icon="healthicons:unhealthy-food-24px" width="24" height="24"></iconify-icon></span>
                <h4 class="mt-3"><a style="text-decoration: none; color:#000;"
                        href="<?php echo e(route('backend.foods.view')); ?>">Food Menu</a></h4>
            </div>
        </div>



        <div class="col-lg-4 text-center mx-auto">
            <div class="shadow p-5">
                <span
                    style="width:40px;height:40px;display:inline-block;background:#E42625;color:#fff; text-align:center; line-height:50px;border-radius:50%;"><iconify-icon
                        icon="healthicons:money-bag" width="24" height="24"></iconify-icon></span>
                <h4 class="mt-3"> <a style="text-decoration: none; color:#000;"
                        href="<?php echo e(route('backend.transaction.view')); ?>">Transaction</a></h4>
            </div>
        </div>










    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\cretive_cox_tour\resources\views/welcome.blade.php ENDPATH**/ ?>