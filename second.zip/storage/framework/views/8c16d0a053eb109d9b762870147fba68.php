
<?php $__env->startSection('frontend_contains'); ?>
    <div class="row">


        <div class="row mt-5">
            <div class="col-lg-6 mx-auto shadow py-3">

                <form class="p-3" id="register" action="<?php echo e(route('backend.login.check.auth')); ?>" method="post"
                class="shadow-sm p-4">
                <?php echo csrf_field(); ?>
    
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="email">Email</label>
                        <input name="email"  id="email" type="email" placeholder="enter your email"
                            class="p-4 form-control mb-3">
                    </div>
                    
                    <div class="col-lg-12 mb-3">
                        <label for="password">Password</label>
                        <input name="password"  id="password" type="password" placeholder="password"
                            class="p-4 form-control ">
                    </div>
                </div>
                <button type="submit" class="btn btn-dark w-100 mx-auto mt-3 p-4 ">submit</button>
            </form>
            </div>
        </div>


    </div>

    <?php $__env->startPush('frontend_js'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
            integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\cretive_cox_tour\resources\views/frontend/login/login.blade.php ENDPATH**/ ?>