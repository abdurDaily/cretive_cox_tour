<?php $__env->startSection('frontend_contains'); ?>

<div class="table-responsive shadow-sm  p-2 mt-3" >
    <div class="header">
        <h3 class="text-center mb-5">All Transport Schedule</h3>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-hover text-center">
            <tr>
                <th>Sn.</th>
                <th>Location</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>Start End</th>
            </tr>
    
            <?php $__empty_1 = true; $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($transport->location); ?></td>
                    <td><?php echo e($transport->date); ?></td>
                    <td><?php echo e($transport->start_time); ?></td>
                    <td><?php echo e($transport->end_time); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdur Rahman\Desktop\cretive_cox_tour\resources\views/frontend/transport/allTransport.blade.php ENDPATH**/ ?>